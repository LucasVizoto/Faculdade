package ex4;
    public abstract class Coisa {
        abstract boolean tentativa(Coisa outraCoisa);
    }
