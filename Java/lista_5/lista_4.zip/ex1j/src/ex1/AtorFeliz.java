package ex1;

public class AtorFeliz extends Ator {
    @Override
    public void ato() {
        System.out.println("Ator feliz");
    }
}
