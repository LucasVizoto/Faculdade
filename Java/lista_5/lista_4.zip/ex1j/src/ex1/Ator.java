package ex1;

public abstract class Ator {
    public abstract void ato();
}

