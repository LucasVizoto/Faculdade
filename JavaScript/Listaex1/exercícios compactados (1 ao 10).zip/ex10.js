function ex10(){
    let lado = Number(document.getElementById('q1').value)
    let A = lado*lado
    var txt = document.getElementById('elemt1')
    txt.innerHTML = "<b>A área desse quadrado é de  </b>"+A
}