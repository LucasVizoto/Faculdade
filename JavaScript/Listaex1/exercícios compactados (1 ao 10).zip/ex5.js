function ex5(){
    let n1 = Number(document.getElementById('n1').value)
    let desc = n1*0.1
    let preF= n1-desc
    alert('O novo preço deste produto é  '+preF)
}