public interface Operacoes {
    public void adicionar();

    private void editar() {
    //metodo default
    }

    private void deletar(){
    //metodo default
    }
    public void analisar();
}
