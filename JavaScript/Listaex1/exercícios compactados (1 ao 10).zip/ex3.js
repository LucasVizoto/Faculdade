function ex3() {
    let n1 = Number(document.getElementById('n1').value)
    let n2 = Number(document.getElementById('n2').value)
    let div = n1/n2
    alert("O resultado da divisão desses dois números é  "+ div)
}