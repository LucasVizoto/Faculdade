package ex1;

public class AtorTriste extends Ator {
    @Override
    public void ato() {
        System.out.println("Ator triste");
    }
}
