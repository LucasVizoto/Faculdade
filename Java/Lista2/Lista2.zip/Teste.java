
public class Teste {
    public static void main(String[] args){
        Aluno jovem = new Aluno(24691, 19,"Lucas",7,8);
        jovem.imprimir();
        jovem.notaFinal();
    }
}
