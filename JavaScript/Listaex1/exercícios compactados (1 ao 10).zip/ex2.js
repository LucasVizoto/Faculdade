function ex2(){
let n1 = Number(document.getElementById('n1').value)
let n2 = Number(document.getElementById('n2').value)
let n3 = Number(document.getElementById('n3').value)
let mult = n1*n2*n3
alert("A multiplicação desses números é  "+mult)
}