function ex8(){
    let p = Number(document.getElementById('n1').value)
    let g=p*1000
    var tp = document.getElementById('elem1')

    tp.innerHTML = "Seu peso em gramas é  "+g
}